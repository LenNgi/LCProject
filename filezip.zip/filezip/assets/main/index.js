window.__require = function t(e, n, a) {
function r(o, i) {
if (!n[o]) {
if (!e[o]) {
var c = o.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (s) return s(c, !0);
throw new Error("Cannot find module '" + o + "'");
}
o = c;
}
var u = n[o] = {
exports: {}
};
e[o][0].call(u.exports, function(t) {
return r(e[o][1][t] || t);
}, u, u.exports, t, e, n, a);
}
return n[o].exports;
}
for (var s = "function" == typeof __require && __require, o = 0; o < a.length; o++) r(a[o]);
return r;
}({
LoadGameController: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
var a, r = this && this.__extends || (a = function(t, e) {
return (a = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
})(t, e);
}, function(t, e) {
a(t, e);
function n() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n());
}), s = this && this.__decorate || function(t, e, n, a) {
var r, s = arguments.length, o = s < 3 ? e : null === a ? a = Object.getOwnPropertyDescriptor(e, n) : a;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, e, n, a); else for (var i = t.length - 1; i >= 0; i--) (r = t[i]) && (o = (s < 3 ? r(o) : s > 3 ? r(e, n, o) : r(e, n)) || o);
return s > 3 && o && Object.defineProperty(e, n, o), o;
}, o = this && this.__awaiter || function(t, e, n, a) {
return new (n || (n = Promise))(function(r, s) {
function o(t) {
try {
c(a.next(t));
} catch (t) {
s(t);
}
}
function i(t) {
try {
c(a.throw(t));
} catch (t) {
s(t);
}
}
function c(t) {
t.done ? r(t.value) : (e = t.value, e instanceof n ? e : new n(function(t) {
t(e);
})).then(o, i);
var e;
}
c((a = a.apply(t, e || [])).next());
});
}, i = this && this.__generator || function(t, e) {
var n, a, r, s, o = {
label: 0,
sent: function() {
if (1 & r[0]) throw r[1];
return r[1];
},
trys: [],
ops: []
};
return s = {
next: i(0),
throw: i(1),
return: i(2)
}, "function" == typeof Symbol && (s[Symbol.iterator] = function() {
return this;
}), s;
function i(t) {
return function(e) {
return c([ t, e ]);
};
}
function c(s) {
if (n) throw new TypeError("Generator is already executing.");
for (;o; ) try {
if (n = 1, a && (r = 2 & s[0] ? a.return : s[0] ? a.throw || ((r = a.return) && r.call(a), 
0) : a.next) && !(r = r.call(a, s[1])).done) return r;
(a = 0, r) && (s = [ 2 & s[0], r.value ]);
switch (s[0]) {
case 0:
case 1:
r = s;
break;

case 4:
o.label++;
return {
value: s[1],
done: !1
};

case 5:
o.label++;
a = s[1];
s = [ 0 ];
continue;

case 7:
s = o.ops.pop();
o.trys.pop();
continue;

default:
if (!(r = o.trys, r = r.length > 0 && r[r.length - 1]) && (6 === s[0] || 2 === s[0])) {
o = 0;
continue;
}
if (3 === s[0] && (!r || s[1] > r[0] && s[1] < r[3])) {
o.label = s[1];
break;
}
if (6 === s[0] && o.label < r[1]) {
o.label = r[1];
r = s;
break;
}
if (r && o.label < r[2]) {
o.label = r[2];
o.ops.push(s);
break;
}
r[2] && o.ops.pop();
o.trys.pop();
continue;
}
s = e.call(t, o);
} catch (t) {
s = [ 6, t ];
a = 0;
} finally {
n = r = 0;
}
if (5 & s[0]) throw s[1];
return {
value: s[0] ? s[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = cc._decorator, l = c.ccclass, u = c.property;
function f(t, e) {
for (var n = t.split("."), a = e.split("."), r = 0; r < n.length; ++r) {
var s = parseInt(n[r]), o = parseInt(a[r] || "0");
if (s !== o) return s - o;
}
return a.length > n.length ? -1 : 0;
}
var p = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingSprite = null;
e.loadingLabel = null;
e.lbInfo = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e._storagePath2 = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
e.gameInfo = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.errorCase = e.ERROR_NO;
return e;
}
e.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote_assets";
this._am = new jsb.AssetsManager("", this._storagePath, f);
this._am.setVerifyCallback(function(t, e) {
var n = e.compressed, a = e.md5, r = e.path;
e.size;
if (n) {
cc.log("Verification passed : " + r);
return !0;
}
cc.log("Verification passed : " + r + " (" + a + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return o(this, void 0, void 0, function() {
var t = this;
return i(this, function() {
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
this.onCheckGame("https://static.fareasttoeastsea.com/remote-assets/");
return [ 2 ];
});
});
};
e.prototype.loadMyGame = function() {
cc.game.restart();
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e, n = new jsb.Manifest((e = t, JSON.stringify({
packageUrl: e + "/",
remoteManifestUrl: e + "/project.manifest",
remoteVersionUrl: e + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(n, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, n = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var a = t.getDownloadedBytes() / t.getTotalBytes();
t.getMessage();
this.updateProcess(a);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
try {
cc.director.loadScene("Loading");
} catch (t) {}
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
n = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
n = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
n = !0;
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
this._storagePath2 = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "check";
var r = jsb.fileUtils.getSearchPaths();
r = r.filter(function(t) {
return t !== (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-assets/filezip";
});
var s = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(r, s);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(r));
cc.log(JSON.stringify(s));
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
cc.log("Updated file: " + t);
this.loadingSprite.fillRange = t;
this.loadingLabel.string = "Update " + Math.round(100 * t) + "%";
};
s([ u(cc.Sprite) ], e.prototype, "loadingSprite", void 0);
s([ u(cc.Label) ], e.prototype, "loadingLabel", void 0);
s([ u(cc.Label) ], e.prototype, "lbInfo", void 0);
return s([ l ], e);
}(cc.Component);
n.default = p;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController" ]);